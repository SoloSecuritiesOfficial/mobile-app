import { apiGet, apiPost } from "./apiClient";

/*
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/

export const getSecurityDashboard = async () => {
  try {
    return await apiGet("/security/dashboard");
  } catch (error) {
    console.error("Dashboard Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Security Score
|--------------------------------------------------------------------------
*/

export const getSecurityScore = async () => {
  try {
    return await apiGet("/security/score");
  } catch (error) {
    console.error("Security Score Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| CVE Updates
|--------------------------------------------------------------------------
*/

export const getCVEUpdates = async () => {
  try {
    return await apiGet("/security/cves");
  } catch (error) {
    console.error("CVE Fetch Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Learning Modules
|--------------------------------------------------------------------------
*/

export const getLearningModules = async () => {
  try {
    return await apiGet("/security/learning");
  } catch (error) {
    console.error("Learning Modules Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Labs
|--------------------------------------------------------------------------
*/

export const getLabs = async () => {
  try {
    return await apiGet("/security/labs");
  } catch (error) {
    console.error("Labs Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Bug Reports
|--------------------------------------------------------------------------
*/

export const getBugReports = async () => {
  try {
    return await apiGet("/security/bugs");
  } catch (error) {
    console.error("Bug Reports Error:", error);
    throw error;
  }
};

export const submitBugReport = async (data: {
  title: string;
  description: string;
  severity: string;
}) => {
  try {
    return await apiPost("/security/bugs/report", data);
  } catch (error) {
    console.error("Submit Bug Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Security Scan
|--------------------------------------------------------------------------
*/

export const startSecurityScan = async (target: string) => {
  try {
    return await apiPost("/security/scan", {
      target,
    });
  } catch (error) {
    console.error("Security Scan Error:", error);
    throw error;
  }
};

export const getScanHistory = async () => {
  try {
    return await apiGet("/security/scans");
  } catch (error) {
    console.error("Scan History Error:", error);
    throw error;
  }
};

/*
|--------------------------------------------------------------------------
| Admin
|--------------------------------------------------------------------------
*/

export const addCVE = async (data: {
  cveId: string;
  title: string;
  severity: string;
  score?: number;
  description: string;
  remediation?: string;
}) => {
  try {
    return await apiPost("/security/cves", data);
  } catch (error) {
    console.error("Add CVE Error:", error);
    throw error;
  }
};